<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'ac65d7a9d92cd68f3f0c89a3cb59f9e1',
      'native_key' => 'core',
      'filename' => 'MODX/Revolution/modNamespace/46c90f0fd8db5e15bb42398de6a949ef.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modWorkspace',
      'guid' => '0cbbb0c49a17d92e292729b452c98544',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modWorkspace/77c28ec32b3211ab4e70b3214c8e90fd.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\Transport\\modTransportProvider',
      'guid' => '3e2fd88f30aa6bbc3a33e8e1685b7806',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/Transport/modTransportProvider/4b8c279d887b6629f289e9bd7b4d5ffe.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '75279baf352d359813ba130096f7d3be',
      'native_key' => 'topnav',
      'filename' => 'MODX/Revolution/modMenu/66adcbc4a567f287f908d7aefb88dffb.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '270a37ff85fbf87757956e981f8bdf78',
      'native_key' => 'usernav',
      'filename' => 'MODX/Revolution/modMenu/9ac6bf117b2008faddf1e99e97b2f0e6.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'f2e2bb09d51630248dcc9b6e63376465',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modContentType/775a56267578a7b0a3533ba371e0cee7.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '61d9b0ed37624a4963cb596450014d67',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modContentType/5eedbf5f2be52c6f8f6fdfe6de65d993.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '593297a2050d15af15f9206721518831',
      'native_key' => 3,
      'filename' => 'MODX/Revolution/modContentType/c2688213b27c6a1630e3ddd421160d50.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'fb815f7a170695e21d2929866e5949d8',
      'native_key' => 4,
      'filename' => 'MODX/Revolution/modContentType/ce485a24f4352a0b0fcf02373c4e6bd8.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '431f3fd18dc95fa60db45c11e279cdf7',
      'native_key' => 5,
      'filename' => 'MODX/Revolution/modContentType/acf96057c44b7349f554792ca95a6054.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '453957f3948ad142a540ab0da4f0f68e',
      'native_key' => 6,
      'filename' => 'MODX/Revolution/modContentType/e88a49d2e68c6f19bcfda86b10b4ec7a.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'bd556eebcd25aec9c1ea9fb94912c246',
      'native_key' => 7,
      'filename' => 'MODX/Revolution/modContentType/0cb0ce776631d86670e80319911dc33a.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'fb339c809500a5e592a876923dc0a5ea',
      'native_key' => 8,
      'filename' => 'MODX/Revolution/modContentType/07f0e7f1b5582f27141082316e45507d.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '95cae0001851c874d07d710807b6a165',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/9af17d295b3dc04f861dd817368a0c02.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0f1fd6fd6fc5e7fe27f705978562d637',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'MODX/Revolution/modEvent/8ea69b5dfdc3bb46ccd9415797aa90c4.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4227b78a96d8ca05792b0f135b62dc1b',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/8521b86f30c14040daba318d7a5eed0a.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a44f22e3a9d0272f61701abd5c2998ad',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'MODX/Revolution/modEvent/0d64bfe55e23d419e60e2882fcd985b1.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e14b37460433c6e02d6b8f9bcd292d6b',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'MODX/Revolution/modEvent/3d5c6d9bb627364a8a12bcc2bdd6b5c8.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd828ffb2a30b45e09a53a4b4efe2b240',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/ee19d2cc76d7beea52b2c5e0eb515446.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '60dfb7740ee6a43ef2c17430d274a437',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'MODX/Revolution/modEvent/37b9628e3597d4eb342c49edecc3f0d4.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4e2ea0f4d8380edd22a506e1778e26ed',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/df6a3a4056a95d4be46d5eca94473ec5.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6618aa3bb3503af36a4d593533359038',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/6b9a2eb9ab0130e5453413c8fb888931.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '298584951ccfb1e11311703ae53222f7',
      'native_key' => 'OnSnippetSave',
      'filename' => 'MODX/Revolution/modEvent/d6e51c0b0b009961a0d52b87345b7482.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '38b9a7b5c5644d9f74069d3e903929e5',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/e7ddd4c9f48f3c3d1069a14c35b040dd.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '10ff7245ac028e619701ad75a799f43f',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'MODX/Revolution/modEvent/eb6be2aa3c774e15a68c967830356c8e.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4713a8413a88c43d0272c83533f4dd24',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/b721d0018ea6b3c89ca35dfa7624dc8f.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '66150305dd782609cbb7dd8a621460ce',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'MODX/Revolution/modEvent/3e982a7060e64fbc896fc1590d81ddda.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '817b3bdab9538b487b18b7c0f3107156',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'MODX/Revolution/modEvent/33646ca550c77e018895df0f7901d15f.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '213bb667495672e10502122b41530b38',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'MODX/Revolution/modEvent/8b2e4e47b5c74cd4b738f93336e82972.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '63117c36cb378b10f05abd9403deb359',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'MODX/Revolution/modEvent/e6c1d1b89bc8d631c73173b9b5f400c3.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4963a461576fefe997ee321c15082198',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'MODX/Revolution/modEvent/54fbe0857512ca90737573d804b1bd7c.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'aa322cd3cd68dbde9b718ab31c4a1900',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/6fec6bfbd47ae87385d5a97eb12cb6e9.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c45dac01ff68d211bc6c43f67ccfbd09',
      'native_key' => 'OnTemplateSave',
      'filename' => 'MODX/Revolution/modEvent/79ea5e432973821618122e38a835cae9.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5767631aa4857988433335f27956dfd1',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/18725720aea3220952099f32c5e290bf.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '70109aaaf3eb34fd3a0b1b98c551e562',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'MODX/Revolution/modEvent/28bd9a7943fd88fa8a4ddce72ab616e3.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e801235e404bcf2b37deab777ceaed00',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/5f7f54b066030ee0c412fe7e17a45188.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'da4a62a8d970b1a9e5a294dcef4fc6cd',
      'native_key' => 'OnTempFormRender',
      'filename' => 'MODX/Revolution/modEvent/97da8a0bad4911633fc80382372206ef.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ffe97b8a65800cb24cbfb5aabea27717',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'MODX/Revolution/modEvent/2368987de0dfe891c3964bdd4e7f4674.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '145cfd85b952bdc5639bb1dbf6f28afa',
      'native_key' => 'OnTempFormSave',
      'filename' => 'MODX/Revolution/modEvent/c697fc3625c61c7dd52d48ec458f35a9.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '68457dbf52219be65d22ab0bacfff8fc',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'MODX/Revolution/modEvent/0a25dc688d2ee9fc93cbb4f6e5467a78.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b484ab44c80bd5bb7f5e4b04a330f664',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'MODX/Revolution/modEvent/57f13f246ad63713ca2f3a885e12a13f.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '828964f5d66266ab34231ec03aeab76a',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/fb9f4dba04be1c616b30d51f59f51e1f.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '51c2ae2e1d4151739b30a321625583fc',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'MODX/Revolution/modEvent/415fb45870d5a86594b0344a35bb2f19.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '73e27c0959c1148e5531bf892b6572dc',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/c7c50018c5309a137d0cd9326b4f7f17.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '599553855e39ce7b5b40b4896df5b802',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'MODX/Revolution/modEvent/79bfd18299d7b388af83e39d5990819f.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4dcf5283815ded03587e22fe5562c4e0',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/d8ae9c49dc88d3c3d20ca79ceecff87c.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4e7914f522b2008516be63e4dc882d03',
      'native_key' => 'OnTVFormRender',
      'filename' => 'MODX/Revolution/modEvent/8763ffea676eb5b90e42713981a677ac.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4d3267cd74765a01f1892dc155d7a8ae',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'MODX/Revolution/modEvent/af6e52a8b6bc0fc78deb73a5647a00ca.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6003234e7d4a95ef78f384da43c1a9d4',
      'native_key' => 'OnTVFormSave',
      'filename' => 'MODX/Revolution/modEvent/3bfd9b6ce9290059ccaf7e623ec1dc7a.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6e8f820fcafa9774935d37e35cd850c0',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'MODX/Revolution/modEvent/e36f8e7ac5e33ab9ec2d95417c6f90fa.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c9e40c6bee79bd7500ae9efa45bf36f5',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'MODX/Revolution/modEvent/5a6a371c3929ff21e26e3ae00dc1f4ec.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd1d9133b02f570a2e52d4179a049989b',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'MODX/Revolution/modEvent/e8c84b1e6071b7376ac4652d39251f0f.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a4dbebf13706d1d6341ac354366d12dd',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'MODX/Revolution/modEvent/b40eb5a7bc139df478bfec9cd0ebaa94.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '87b362ec819bcf7cf390e6396ec58140',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'MODX/Revolution/modEvent/4635bb56a7819c98a486bd59094d3cac.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a313eec306de6d8f5041520d20ff86a5',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'MODX/Revolution/modEvent/ebb98aaf6e999831abdf92ffccc3c64e.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3c9b29bcd14c26ed180b03a5e09e479b',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/29b503a1b03a7a4d5fd08a956c17bb8e.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3039716b8d2475051fca770d2729e10a',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'MODX/Revolution/modEvent/386936e53132bc5449302989c3228689.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c9826ae6bf3c848f28ee188d010507c7',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/1c9e9e0b05b94ee4299073589b88b037.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '06ce1dde43571baf8d983d4de13c1bd4',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'MODX/Revolution/modEvent/42cff38bc515779c8204bee33c69c5da.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5e41e1357e68054d47efc5d27383dced',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'MODX/Revolution/modEvent/786598fec213a13a7a97d49157bdf4cd.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8e6de63e5fc565b8bf417853eb76ed05',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'MODX/Revolution/modEvent/e2f77a27a8e4c0eba4b0e01a0e55d451.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3441da74e63b3fc3b3c9cd3d9be4479c',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'MODX/Revolution/modEvent/5e67625e98aa6d9191112ffd7338a48a.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1903c2023172e5d35a7c6cd7b17f859d',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'MODX/Revolution/modEvent/c986042b3ef1b4847929c8248e7cd79b.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f30cd9fcb1b4f98d1d90a85642034d17',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/9c8b917b70de933e9b086aebf6849486.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b893323037dc39f64778f4788754e606',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'MODX/Revolution/modEvent/d193a408308b22dcda33a428e6b44afe.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e7d5d4b7bd38f22e1b3023cb99f05d0e',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/90177aa6fc03ef24d94ecdb2f887f3d8.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9f8f11c6aa77f979d70a38bad5c6ffb0',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'MODX/Revolution/modEvent/5f5bc67819aa9fd9fe52269fb7b5be8c.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0e308edbd9f3a6f4880eeefe2b0e76ef',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/ac35db0c473c80ed76f624770525075a.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c58320cf7c873b197ee236b4657d773e',
      'native_key' => 'OnDocFormRender',
      'filename' => 'MODX/Revolution/modEvent/30c0164142123b6a0f24cbb0d00c4945.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b4fc6418bd6d4fa72e04dd445d9461a1',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'MODX/Revolution/modEvent/23862c2804faed31a575ff9ae6a2716f.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '70d59e246c5495b338eb2466c4af5ade',
      'native_key' => 'OnDocFormSave',
      'filename' => 'MODX/Revolution/modEvent/f207032ec8378a6f13727dccbc3458e5.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '666ede3e7c7fbf8b0e78187f2474439d',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'MODX/Revolution/modEvent/003bd3b9ce88c7c595d40c3451788c60.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f557b062cd4c79c96b5b6a0613cb6f6e',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'MODX/Revolution/modEvent/bee64bae8da93caa4b735ab5e60d67dc.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8c0df29cbb3615ebcdd0c5fbfa001c12',
      'native_key' => 'OnDocPublished',
      'filename' => 'MODX/Revolution/modEvent/2dcd654745e7e9a463847195494d42de.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '407fcdedef8209b077a14f864f425c77',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'MODX/Revolution/modEvent/ecc7f16df94ac9cf29ce959ab59e826c.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '86dda610fec2225699e878b7c70c431e',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'MODX/Revolution/modEvent/1740b6622b1172b2898ae36d8b6daf64.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '01c3ca37504bb386c79c64c5d6d0250d',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'MODX/Revolution/modEvent/0d4fff34c5f11b3ab253a0ece9f8295d.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ee19ec450f61ea4518bc44cef5ce944b',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/4fecae03656cfd35e8fe29206db7b61c.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '13ada75293771d1a4fb55c01c42be010',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'MODX/Revolution/modEvent/522b8094c402c4db67bdf796348acf08.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b86641184b9f4235d032750a0eeb60fe',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'MODX/Revolution/modEvent/17ca684d6eb56f3a4f2da5cbb29a81d2.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c2b7cdedbe58878bd938d0931bc04822',
      'native_key' => 'OnResourceDelete',
      'filename' => 'MODX/Revolution/modEvent/3f0f2c9a1d960e405424483126993229.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '245e33ab20f1a44e5c1e976623d1b430',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'MODX/Revolution/modEvent/a520ccf3d102a5dd93e76fb6570949e3.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1394229f1daacb33a0b4b2d02bf7a751',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'MODX/Revolution/modEvent/818cc4855e748f9fc456e6b05da49eb4.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8709d46a0f0d5343b8ed00c7540441dc',
      'native_key' => 'OnResourceSort',
      'filename' => 'MODX/Revolution/modEvent/71f35faaaa738be83c20ad50c3b7d9a5.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4accefc8e9131fa1d46e9f9de6d2f84f',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'MODX/Revolution/modEvent/d065a0916b06324a4cdda04e8647ad71.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f0dd8490ebf842b59b00d2f965a82325',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'MODX/Revolution/modEvent/4bfa1c49efdc63e18951e89f5e5f71a3.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0914f51ecebf89de386a406d62b8debe',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'MODX/Revolution/modEvent/342cd29a0879374a0241f688bbdff42d.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4a7b61dd7b7d58a452945af5e6dac1f9',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'MODX/Revolution/modEvent/5db967f01421a41c716b8961f10d2ac9.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c9d1768cf7c76dd50abc6fff12038b9e',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/170d7165045eca6bc08cc640b52aab51.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '453070698f7a7a0050739a53cbc1834d',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'MODX/Revolution/modEvent/f522206582beee1e578a523210e834b3.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2e8500da729007b098b68a4c3a28ff71',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'MODX/Revolution/modEvent/def7e2525ff643a7183459ada3ad4fc4.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd40967d6249e3e49e4f630985ee6888b',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'MODX/Revolution/modEvent/4ce8463b71bf2e601261fb45c2540473.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8c7e02adee96c4ae742c73d0855b0794',
      'native_key' => 'OnWebLogin',
      'filename' => 'MODX/Revolution/modEvent/0c407143bcb994713fb1488658c9af90.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd2627bdf1c99be674fc610861d54fbe8',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'MODX/Revolution/modEvent/9066bbcfcd239771cbc8f846d7051396.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f7a90684a3d8e42949d086be8907f613',
      'native_key' => 'OnWebLogout',
      'filename' => 'MODX/Revolution/modEvent/154740f4215b7bbe5b6b5be2d1895f6c.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd7df839f9c14fb3a9c6973f87c194487',
      'native_key' => 'OnManagerLogin',
      'filename' => 'MODX/Revolution/modEvent/24996ceb0fb52d568320c6c061aae0f3.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '536605508d24f64bfdcbd4d999727477',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'MODX/Revolution/modEvent/a9ebed17124a61ef5ea42144ef3e4d67.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f1ea7893bd397cc70d3be52a8ccadfc4',
      'native_key' => 'OnManagerLogout',
      'filename' => 'MODX/Revolution/modEvent/03c1e825cff426fc8a07e296d27bf0a3.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8eed8e3cc535e0d9daa0a42fc9484f06',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'MODX/Revolution/modEvent/25da43d2924746045febde8d9e84f3c1.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'db7ffd16a890c5fcbe690eaffbde39da',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'MODX/Revolution/modEvent/c23d86f114571473cf7a745d3ebde924.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '618fa0155128157f02a9e1e4e5494756',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'MODX/Revolution/modEvent/b252d30a4490a90983700db365cd242c.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c5b9c622f1dbdd0e48e52bd974fca5e3',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'MODX/Revolution/modEvent/47ac6dfd469efc29a537ea3da4d5a906.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7f7d6de720a23f54cccf6ee6d575c0a1',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'MODX/Revolution/modEvent/d572f73706fa32253261a696828aaca1.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e7c0e5a627dca59e231ad13f47ea35df',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/60746e1b182544bbe841fd079e57c85d.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f8fb2f10b687b9d74154289e9f702bd4',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'MODX/Revolution/modEvent/6cbd24c973e689d7ded6cc61c93d6130.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a8861301fc48801337c9c35ae942911e',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/97649b92e5f9192242240b7a2f128101.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a9d834c4b9c6407f0d9c5449d63be32c',
      'native_key' => 'OnUserFormRender',
      'filename' => 'MODX/Revolution/modEvent/bc07ed54e28d85751f90dcce2019f75d.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '528fd8d36702a83cdee1b42d006fdcf8',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'MODX/Revolution/modEvent/9df36be3744abbeb841796ee8437b364.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '01835a04ebdc6b690661216059991303',
      'native_key' => 'OnUserFormSave',
      'filename' => 'MODX/Revolution/modEvent/3fed6990209bfc3c25671424812e8072.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '32eef9a0ab84a7f33118469503e15b7e',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'MODX/Revolution/modEvent/16104eb6fcb557055e0d37b34416612b.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2f553072be45757c6d0c5e87c6f213e2',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'MODX/Revolution/modEvent/5bea9447a9319e0324c262056c4873e3.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '24838088b3304b938204a252739bddea',
      'native_key' => 'OnUserNotFound',
      'filename' => 'MODX/Revolution/modEvent/f8638121933e8be5f3a6ff19569ca73e.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '558b62cf8abfea03ac38a24e11bef8fc',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'MODX/Revolution/modEvent/b7f445eb13b1ee36af3a1b9f470af9ab.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '430ad38e7eb753bad5566bb5dd60fd0c',
      'native_key' => 'OnUserActivate',
      'filename' => 'MODX/Revolution/modEvent/fb2538f9a6eb9b8fd04806c2a9589ad4.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a96129cea6565b07b8206af14700611e',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'MODX/Revolution/modEvent/d2d825743da4fa5eb3937f264bb7a30a.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8dd6d7743d2581b93928a044c765cd47',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'MODX/Revolution/modEvent/022fc4c6a8f2f781aba83b7435ae50de.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0ed1bfe9e74ab9607b6e2fae138e4ea6',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'MODX/Revolution/modEvent/cc1d5123f4af576911ffe2e86eabc780.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '51284f490a6654e6b6858c865cb57fda',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'MODX/Revolution/modEvent/37fe1936a528389ee8637b25a3862d53.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5c658bde95654c34842b0140964ceaeb',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'MODX/Revolution/modEvent/9f517b83f3e1fb2db4ab14fc9254603d.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e0193efc488f9aa6e9718df9e520f594',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/f911cf934fcfd4dba01c401713b1b3db.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ca8bc0afd16430fb3dcabfa31bd095a4',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/fc17ff522a93440e3cf64101f2c5657a.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3852604c16d6d19abd6f3e833590c54a',
      'native_key' => 'OnUserSave',
      'filename' => 'MODX/Revolution/modEvent/175fdc8fa3f7aac0dd9cd96dadc79ba4.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f7707060bf9ad5cb8cf675d8524e0c8c',
      'native_key' => 'OnUserRemove',
      'filename' => 'MODX/Revolution/modEvent/87b102c6bf16c84f3b3c339a56aea3fd.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e8ce05eccffe7523a15e5434c5498a49',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'MODX/Revolution/modEvent/7e78ee079bc1944f9abfd946f933e64d.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8918e87f332265b64139c5a65d57e905',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'MODX/Revolution/modEvent/c5fd1d9fa98ce7049dd0d3f537f0f7f1.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7d8d229dd7f04a3d6b2fd98778aef255',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'MODX/Revolution/modEvent/d9c470813a7039a68424e47bed9f9af7.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5d0750873a85a1e0d5fc092b67e8f6b6',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'MODX/Revolution/modEvent/cc7910815423ad7a07dbf0a507da2b31.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '96d1de3d9ddc68f7c54fedac008ac459',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'MODX/Revolution/modEvent/0679fffeac526701ed0e2958452c1f30.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd5ae269e0e9992464e6070976bc4c223',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'MODX/Revolution/modEvent/ec9ab6a4ac0df440d502ff7d1df4ff33.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fa37df5dce8cd691d92c717330bc5a2a',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/b78c087d490fab7b7c9425701e904c1c.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '48dfd27d0ae3b174729983a6c67551c2',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/cfa611fd33d503200ea5ce045e102118.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b6c525621e1ea23c69430d70803bc726',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'MODX/Revolution/modEvent/ff27d6c1c28d392eb598e43c0d30a0e1.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8870e1624e9182282278c8ee02363a3c',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'MODX/Revolution/modEvent/284e4945d8a7d9f85358f40d6e502dc6.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd4716221b84dba82790980a121cece4a',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'MODX/Revolution/modEvent/56bc1f769ac38cad560cf3d8ce0a0739.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '581722349299ff92a679c4288e877149',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'MODX/Revolution/modEvent/32847c2b414d5e7ae17ce1c426dbd4a2.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e7dcaae841fa0607e1ebeac5bc5a4f7d',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'MODX/Revolution/modEvent/9c1455c8b4a1f2f96787db8194802f21.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'efbaf0adfc82e5e4922f4c8f819be31a',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'MODX/Revolution/modEvent/a1df7b90fcddfc54730b98a02c0b043c.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '98c5b4473b1e46c68ab71c841bf386ab',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'MODX/Revolution/modEvent/8fef7cc1ce381df28e186018a7c46d83.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '633ce527eb228d1dc2b46b9a771a951d',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'MODX/Revolution/modEvent/0b3a66fbf5d9fecea7ca05786ca1bbff.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ade203707cc43a176adaf2f543ddccb6',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'MODX/Revolution/modEvent/6205395c01bfd3902eb323d9bbcffb71.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1f900ccf1cfa252c13527c56c990d968',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'MODX/Revolution/modEvent/de993ba6ffe9cac527fa6257a2470112.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '19a5e7fb779aecc6bcd49d16d0fb7d6e',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'MODX/Revolution/modEvent/fb30bbf17b17e5d762ad4e230c096df8.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2552756b4b725b499187e4969245c2b9',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'MODX/Revolution/modEvent/5af458b7ea24d251f9b6e3b2c76a126f.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '28379c08ecaebd91b19b8232287ab580',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'MODX/Revolution/modEvent/3db68186a0f954f0c68e95a0d79ba561.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f61866fd34b899ae507ded46d8ef6a9f',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/c5b6053f1a80b668f7f2f758bad687d8.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '84f5c451297bbeed102bcd8734dbf476',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/77e08a9f5f88febfcd3a54342067a744.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '64aecb9367cd529d4ff7571dec355795',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'MODX/Revolution/modEvent/1a9d279bdbceaedc6f4091fc154105cc.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c66a40ef27f242b2d897cd8d610e19e6',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'MODX/Revolution/modEvent/11da861cc586df8d61778637e58784af.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd8d02d385ce8ab824b877420746a193d',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'MODX/Revolution/modEvent/e4ce66ddf995b1a29eec731ba721a124.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1da4c26711ae355b77c5763c965c74be',
      'native_key' => 'OnWebPageInit',
      'filename' => 'MODX/Revolution/modEvent/6b37c46486b875dfc299fb22afb6340a.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9dfc1a324ff30a28b1abd7ac13b8a1b7',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'MODX/Revolution/modEvent/eb8a1d9990ce36c7c4306c589c90c659.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '193aa3a15745bb265665f4160094d47c',
      'native_key' => 'OnParseDocument',
      'filename' => 'MODX/Revolution/modEvent/951fabba637380bd3ab0c5056104a812.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '95100427b6a682fac397e4e52a0148c3',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'MODX/Revolution/modEvent/99e2cee96cc1310e0d790f3a9788a699.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5b92a3acd20d4a0a343954186d28235d',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'MODX/Revolution/modEvent/01dffdfd2de8c4cf2d87ff941ae1edba.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0278843bdf8244fc4610c7b8bd53a95d',
      'native_key' => 'OnPageNotFound',
      'filename' => 'MODX/Revolution/modEvent/0720522792082eb0714cf087a1f89d04.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a2e03d1d06236569fe4caf32de482f6c',
      'native_key' => 'OnHandleRequest',
      'filename' => 'MODX/Revolution/modEvent/229f006053d037bb80a377f01c816b3d.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0290070c06e565b1467cc6bbea2f29b5',
      'native_key' => 'OnMODXInit',
      'filename' => 'MODX/Revolution/modEvent/e71621e0f4c4203769118f388fc63dca.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f3d0b7cd3b813161d46de9d2d9f39c3f',
      'native_key' => 'OnElementNotFound',
      'filename' => 'MODX/Revolution/modEvent/915b6dd2f7ba7888d31a66048f5c80b6.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e52f25c07540802e43d6e9b5579cba78',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'MODX/Revolution/modEvent/4b67805fcb636158619e21f166191a87.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c2351b3385f0135bebe16d5882a36b1b',
      'native_key' => 'OnInitCulture',
      'filename' => 'MODX/Revolution/modEvent/0467464438cbd64aef9c7b72e46f4364.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ad55aad88b059882bcb4d1fa9f25565a',
      'native_key' => 'OnCategorySave',
      'filename' => 'MODX/Revolution/modEvent/47dcef441409a1837e7261d48c38cd38.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'dd5d614cbde4d7250b47ad95ecadbfcd',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/a48c6fe001cf54e3141ec1e5a4e802fa.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fca85215cbb39b403ccc32dbff60589c',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'MODX/Revolution/modEvent/83f5d278ce0872a18d1b35a05dbd53f8.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b19a21e3fe5317f61ce0c6b915d267af',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/233230288856a63322789a09b7c06b7e.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '382b4e5bce28c16949bcb7cf3cae667b',
      'native_key' => 'OnChunkSave',
      'filename' => 'MODX/Revolution/modEvent/c6669954bbb6f6a8e4ed4214c37bd051.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '225981e6211a76923431f7ca0e19bd78',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/9113bc1ea467ba329d633e5e2e556230.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'df42c56108bbe261b767a21ce0b6355b',
      'native_key' => 'OnChunkRemove',
      'filename' => 'MODX/Revolution/modEvent/e1311a9f3f77fb851126bc2b11f44bba.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5102afe61e1023d683982ef17edbc19a',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/d0a699a18f5cb7330822b31264101588.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ac3120a97c0343476cc5a9636669cf4f',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/6f27f55a7978a72dd3fd9987f9c43330.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9f7daa6e464a4afe4715820f090dfff9',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'MODX/Revolution/modEvent/7c535690886b87cb373c345899c38ebe.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '275e3a522005a53341d4568fbaaf866c',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'MODX/Revolution/modEvent/481186801852e54aff12d969adbc4f69.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2a56e0510d868cf6792df5ed748f0f65',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'MODX/Revolution/modEvent/f56404005d87e55c63ddaebfb40f7799.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9006856a0e13152c871347e3cee5fc8d',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'MODX/Revolution/modEvent/f8df44d484d707a3438415c1ec579b7f.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '02a93001224d21d74e533cec1cf11894',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'MODX/Revolution/modEvent/969af7882a5e029a8b27b336a5207f2d.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4a4c1da573ef90a75590cccc608d01cc',
      'native_key' => 'OnContextSave',
      'filename' => 'MODX/Revolution/modEvent/a0f6fb78586a3c411435d27a2aacc6d3.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '70a9f0b21ca55265dc5146bf438f517c',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/e22aa4508f5ad6a9aed1b9777522870d.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '429a3ec18b2ef382fbaa7d73edff2628',
      'native_key' => 'OnContextRemove',
      'filename' => 'MODX/Revolution/modEvent/4cafece2ccf80c0023de57c3b18b5a4f.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e207c40229d28cac4aa42f1c438c365d',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/d21887b553ec9e2b690e5a19ffd84e5f.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fc6b960f3e06f069ad601d76e95ac055',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/5693d56528288852f58b74a2f705e2bf.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1d2d6795d31fc729fce9550de53cf01c',
      'native_key' => 'OnContextFormRender',
      'filename' => 'MODX/Revolution/modEvent/b3f4d57459fb8dbc0c72a48f6c31b53b.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '037f3256177d1092f0fe9a0bcbc307f5',
      'native_key' => 'OnPluginSave',
      'filename' => 'MODX/Revolution/modEvent/c917acf75c9ad4b17d7d6b6bcbe490c4.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'dea163db914667dbfe9a132295179f82',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/81fd1eff35fad94c45e3c6d3202a107f.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '43a1bd05105cf3cb424e6f2d2091cb45',
      'native_key' => 'OnPluginRemove',
      'filename' => 'MODX/Revolution/modEvent/11534eea776fc558f7cda7c0412d7f45.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3cdf298b4a73a1880df06d49b27154ba',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/05943ec594adca19397dccfc4b6e8416.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '01677c417576e57e4299268171559cc3',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/b47c5aa5f60376ba35ede3b52b6ac468.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd1341bb023dc115b88cbe558ce1b2b8f',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'MODX/Revolution/modEvent/5ff440bf5afce6324e4f0af44a1bba08.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '066ec827033b348f1d0ae45d4f302926',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'MODX/Revolution/modEvent/1dc5d16608de8172cb03cbd0b9411e6c.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '313b8de4fed8102ecb5af25c5d2eae31',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'MODX/Revolution/modEvent/cfa3ef6e87f6aa464bceb022a07c0425.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6a2ccd1c23f771db4e1072466309b473',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'MODX/Revolution/modEvent/68915aab4d343154ce130de4640fa226.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b8f99f7481d21284599010de13c49abb',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'MODX/Revolution/modEvent/435ad89c18803387d5f5e55324f90bf1.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'dca6697e4ffadab4c33ea088fe9b4037',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'MODX/Revolution/modEvent/da4bc2af41908a0148d92fea2790e895.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f82fc205958f1933e1ee640a75c86fa2',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/dc846b5bfa2c75d7511fbb201170e6f7.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b408a04d9369e42dde2008cc6e9e66ae',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'MODX/Revolution/modEvent/bc6d542b434072b8dc301b83a5e0a866.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bc859d7946e059d79da2e370cf2f742e',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/fe213ef5a53ac96929a45e99478e432d.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c235d74f93055221ca42ac50c424120a',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'MODX/Revolution/modEvent/98a089d564728debcd5ef15611c53d14.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b264295e21976ec4e877035d89976a2a',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'MODX/Revolution/modEvent/a96485d97757eb5c6da97978c35c7474.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '18e62d7d46688f7c4bf35c58c6b0e1d7',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'MODX/Revolution/modEvent/e7cf03de3adea43c291198820b319b33.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c5f9d80592e69fa23b0e53ea908d09c5',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'MODX/Revolution/modEvent/e94d4d6d175ff92c04a242e9c0730f89.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0c534d923bd39fd034e1aed161d3a598',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'MODX/Revolution/modEvent/2566e673634fcb47d5e3a580c2c006bc.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '38c3a3a712e34385a8d909925efbbe0a',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'MODX/Revolution/modEvent/019f4a2d8bc7acfee82486d01c00d6a6.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a017f10db8d73044bbf7776b5bf7b8a4',
      'native_key' => 'OnPackageInstall',
      'filename' => 'MODX/Revolution/modEvent/5ed94038d84d27621b340dfea2ce98ea.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bb1533bdc667726ef8f158713862d90f',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'MODX/Revolution/modEvent/3810c9f199ced618ffce06936dafc9f5.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'cb33edd5a0456d210b3d192dd2dc59bb',
      'native_key' => 'OnPackageRemove',
      'filename' => 'MODX/Revolution/modEvent/d655d6356261923a532466f71d3f4b55.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c5fe839a488df12e7340e7e1067ecff3',
      'native_key' => 'access_category_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/4f14a83e36276112d8b678cdb0bbcca8.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2d228aba1f1e7f6feb36fb2299e1aae3',
      'native_key' => 'access_context_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/d8e3753faf3dc8efc5d3929947e3fdef.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bcca8a0ece4597488f6e9e6f7dad1ad5',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/215b3d793592cbe243cf9c9e4edd7475.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'de3d181b079be5ff3a99631dc0632b90',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'MODX/Revolution/modSystemSetting/8b1e5e851da649442e0eb33816cefd22.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cc2d14630b90b08703b3926697cdabd1',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'MODX/Revolution/modSystemSetting/3ec504aeb978ba9846a12c20981e953f.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8f131f110a8471bc0e9e84cca53e34f8',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'MODX/Revolution/modSystemSetting/407a3d0de86b6eba64be75d7befd88e7.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b8558b980fe6cb9fb4bcadfe803faaf8',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'MODX/Revolution/modSystemSetting/05a558675c06a5306fa7aac09299e24d.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '58b93f956668fe569d9c4ee3ed180080',
      'native_key' => 'archive_with',
      'filename' => 'MODX/Revolution/modSystemSetting/bee65c48f102c1e7ae9498c6b1872f82.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2a090e519b6b33a6ba01313baac79f4e',
      'native_key' => 'auto_menuindex',
      'filename' => 'MODX/Revolution/modSystemSetting/8803689d6d1ebb901eb54f9db04b91e3.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2a4eb5a7049569719867588c9b3dcf96',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'MODX/Revolution/modSystemSetting/eec0eb6adcaa1159d21ce7410f3a9a07.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '64988e2aa2f2d0364823e2899c496537',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'MODX/Revolution/modSystemSetting/272c0438bdac2ce3e3fa1af89d45fb0e.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '72bddc238bfc7c018d1f8ae720332784',
      'native_key' => 'automatic_alias',
      'filename' => 'MODX/Revolution/modSystemSetting/b344131c93c78b88740ddc1cebc15ab2.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c007f4259c2731ce05f219e9b29c983e',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'MODX/Revolution/modSystemSetting/95eec7c384e56f1166eaf7d85c5e1f3c.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '977002563b60d1cf84216fc721b84c23',
      'native_key' => 'base_help_url',
      'filename' => 'MODX/Revolution/modSystemSetting/2969895bb642346a014cd3e091dde407.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '00d4bc07562a567a9d49402e2bc47cbf',
      'native_key' => 'blocked_minutes',
      'filename' => 'MODX/Revolution/modSystemSetting/eec7ac3c9004c251918b97dd02e19097.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '97df4b09b9555fa5a7a868d4ebf1a47d',
      'native_key' => 'cache_alias_map',
      'filename' => 'MODX/Revolution/modSystemSetting/123ed2573c8bb9ff9146aa550533574a.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9457091ed242da08927b4f5cdf9fee2d',
      'native_key' => 'use_context_resource_table',
      'filename' => 'MODX/Revolution/modSystemSetting/1df0ae733ac7e0e25261488484362e79.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8cff77989983427eb5dca411dd7f4530',
      'native_key' => 'cache_context_settings',
      'filename' => 'MODX/Revolution/modSystemSetting/5367be9b889ce7dbd1c0a57fdbba0f7b.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0ff4cff6893a2877d31bc3a40b7c50e3',
      'native_key' => 'cache_db',
      'filename' => 'MODX/Revolution/modSystemSetting/2d06b7847d3f251dc5636a103912b368.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '89493cac9c38dd25e94bf46ed1296736',
      'native_key' => 'cache_db_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/82bb4b7972cd83eedff7f97c707d90ed.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '38f3f702b6c1603320a2d6f10b88cae3',
      'native_key' => 'cache_db_session',
      'filename' => 'MODX/Revolution/modSystemSetting/ad6b1db0e15f4dbf758c54dc099c2820.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dbea69faf1fb83c871e86268fe57c7ee',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/9cf793b7be9fa2c1ac564868d2e2bf36.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '35cb021d911c9d259af64ea8c8a86bfa',
      'native_key' => 'cache_default',
      'filename' => 'MODX/Revolution/modSystemSetting/54713c3f9a86d30351d7a8dd00b43750.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '32e935bf860875aafd05497fe533480f',
      'native_key' => 'cache_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/390428dd2f3d10745f87152369241cfd.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '03350efe89cd8860a89f8476617412a6',
      'native_key' => 'cache_format',
      'filename' => 'MODX/Revolution/modSystemSetting/354e010c6759c183217c83edca53756a.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a0ea06dfd68bbc9e5b4381cc17505784',
      'native_key' => 'cache_handler',
      'filename' => 'MODX/Revolution/modSystemSetting/c957250c2cbc5d60bd96358073a85b22.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2d8d8d6dc899434f2fec6bc2754e4049',
      'native_key' => 'cache_lang_js',
      'filename' => 'MODX/Revolution/modSystemSetting/32f875b7ef53cce262eac41561b28e1a.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '27ab2f91d4f77456e0ab51699b768af9',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'MODX/Revolution/modSystemSetting/416ab540f603c4a30a8e1e727a242c0f.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8c28da7823b8a4a3981df71622b72eb8',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'MODX/Revolution/modSystemSetting/97346c02ecb06a87b1742f7c634a9a67.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e0348e99cc3dccc2d9649271ae8a7d4a',
      'native_key' => 'cache_resource',
      'filename' => 'MODX/Revolution/modSystemSetting/769e494bcfdc6e3b708bc7419e2f01dd.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1a0d6a1dc7bd0064ab1f102054e1582b',
      'native_key' => 'cache_resource_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/0c5a3048bcb15fa1aa7c722d76e6b938.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0ad9e291d0a5af1073bcfe78e803d785',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'MODX/Revolution/modSystemSetting/3a2e831930a3a5c68326336d092417ef.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '88792c044fb0498eadd9af57f7b9d752',
      'native_key' => 'cache_scripts',
      'filename' => 'MODX/Revolution/modSystemSetting/40cec9565db8c810de6496880fa77287.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '75b5c42d19b7fc3cac6d1c488e4fb3bd',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'MODX/Revolution/modSystemSetting/18964bac1017103cf3feecb144189bad.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dc84c1db1991466cc9343a3877b86bbb',
      'native_key' => 'compress_css',
      'filename' => 'MODX/Revolution/modSystemSetting/af4e692a0d00507967134a29936d7630.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f2aa8e72f05e39b56cbc355b9dc31705',
      'native_key' => 'compress_js',
      'filename' => 'MODX/Revolution/modSystemSetting/06045ac9fb23f07816182b6c4b1cee57.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4854bdc328dc40c3384c6be6b08b5fba',
      'native_key' => 'confirm_navigation',
      'filename' => 'MODX/Revolution/modSystemSetting/a1a6f24aa1523370382400a05932a72e.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd10bb6295c315fbbbe759ffcf6798103',
      'native_key' => 'container_suffix',
      'filename' => 'MODX/Revolution/modSystemSetting/44e2d3b2beabc10c5d4fd2c9603ee7eb.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a43bfcc23ec68870f497f21198c5f602',
      'native_key' => 'context_tree_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/64e5983dfbf3fc2a4520d9b1539e3d9d.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a3b24aea4aadc14a4a2e1eba4e040e4a',
      'native_key' => 'context_tree_sortby',
      'filename' => 'MODX/Revolution/modSystemSetting/7d898e1ccad30c67eea5ede082396352.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7b07ab54eb78955bdcf2952275c90b85',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'MODX/Revolution/modSystemSetting/44886076a08260d294b245798df479f7.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9d78dd5895996d8c39612eb56c16316f',
      'native_key' => 'cultureKey',
      'filename' => 'MODX/Revolution/modSystemSetting/3ca5a00cd0215f303bac27437511eaa3.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3e11bfecd29e2101996970981c9c7cdb',
      'native_key' => 'date_timezone',
      'filename' => 'MODX/Revolution/modSystemSetting/228a5de9a36add3b70c615894847a1ee.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '613f7dcb981c990d55d10f023b586540',
      'native_key' => 'debug',
      'filename' => 'MODX/Revolution/modSystemSetting/59aee11ec3e8200262f304e2f775c567.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e4a39eb8d0506901dd6db5b9860825d4',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'MODX/Revolution/modSystemSetting/a2f4d9a0de10a9f7b5b8277d63a33e4e.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1a2542f7646706e4d5003ead5439478d',
      'native_key' => 'default_media_source',
      'filename' => 'MODX/Revolution/modSystemSetting/789e7e4120645a9a885f4e6fad654ebc.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '86ae6ecc372d30bbf656948f4b8f73cc',
      'native_key' => 'default_media_source_type',
      'filename' => 'MODX/Revolution/modSystemSetting/6a35b9a6799fad8b27506a1d7ebb918b.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6edbca053e9c12a34c7a29df0d514ebd',
      'native_key' => 'default_per_page',
      'filename' => 'MODX/Revolution/modSystemSetting/929f6afb33a0cbdb1acaebd3f5e33034.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6a1d7fde13f9c671f9732e63e09e553d',
      'native_key' => 'default_context',
      'filename' => 'MODX/Revolution/modSystemSetting/8d871e6d4c4162c9df1401876944cf94.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1913e31c7e779f1bfd6d63038f6204ff',
      'native_key' => 'default_template',
      'filename' => 'MODX/Revolution/modSystemSetting/dcc8afe1525baf795f76278ebef9e697.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b72b65c91b93e35f0ed4ba51f91afe67',
      'native_key' => 'default_content_type',
      'filename' => 'MODX/Revolution/modSystemSetting/f64f11aa43c56641117b84a565911716.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '91614f81d0f9444dc22770ba649793af',
      'native_key' => 'emailsender',
      'filename' => 'MODX/Revolution/modSystemSetting/36dfefa43b2fe427dbdcce246731be04.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '628e5e1fa7016bc16d3071e668dfc1be',
      'native_key' => 'enable_dragdrop',
      'filename' => 'MODX/Revolution/modSystemSetting/bed5b955c6e48cb6642968bbcc130968.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bea30b96f219735a21967c01dea3eaca',
      'native_key' => 'error_page',
      'filename' => 'MODX/Revolution/modSystemSetting/3630a7e01efddfc76c636bbe16e3c517.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9b79b75beb8cabc3777e19a04d6ee300',
      'native_key' => 'failed_login_attempts',
      'filename' => 'MODX/Revolution/modSystemSetting/d4f042c2ae7ea861e452ead71b352439.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '25993065ad97fc5166175170bb3a33a7',
      'native_key' => 'feed_modx_news',
      'filename' => 'MODX/Revolution/modSystemSetting/3b273c114d5ee60aa24bfc411706b374.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4ac797becff0d8a9efa744448c3a156d',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/7426efafbf733da05b873ca25be72fef.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7d12afa3ff0a121d1016e26ada84fef4',
      'native_key' => 'feed_modx_security',
      'filename' => 'MODX/Revolution/modSystemSetting/8e72f2ab8a268699758447ea56a3a6bd.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'db06e06103d83edba8f28b567de9e700',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/5ac01ff36fa0860e6663a164c3eba521.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '568914c0d3421d7c504f802bebfd01f1',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'MODX/Revolution/modSystemSetting/55a085b088d31c8f1fa71bbf4080d308.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '51ef4b985f536b76c4ee96c9bf2ff0e4',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'MODX/Revolution/modSystemSetting/15ecd9f30e4e3d099cf6d9e63c87311d.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9511c65ec9eb32af30d317da55a3dd71',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'MODX/Revolution/modSystemSetting/256872c1e4011a9d7b6c3e2a59ad3899.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b7a4b9a2db9fca6954ba59b336d8711d',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'MODX/Revolution/modSystemSetting/3048d8da0fb8e88deb04717dcf4ff550.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cb939773b818987e8f5a2ac302638872',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'MODX/Revolution/modSystemSetting/c4477808364ca4fed439daef7d8b26ac.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b1352767bc2fc3ba282ac590b9823f06',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'MODX/Revolution/modSystemSetting/061740c88e5f5a56f84cfa63cf29d0d9.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f421ea01b2da5caeeb33fb7a083459f3',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'MODX/Revolution/modSystemSetting/78c2838ed92602c8ccba72fb2f34d28a.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '462e169bcbdaffa1da1d8ee692d58198',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'MODX/Revolution/modSystemSetting/cfcc9da1a70a180d968994afd251bf9a.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1cca52320a17042c9e14c76c6d0e4397',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'MODX/Revolution/modSystemSetting/ca8643ef97bf0a2f5704943a3b47e628.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f6a025ddd4ca00c425e9a951a8e8fe1c',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'MODX/Revolution/modSystemSetting/350ce83582af9016ac8cbebd5dd35c61.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cba9d9b1fd97d56f36d6112783fcd272',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'MODX/Revolution/modSystemSetting/938710184f6ae31b259780dc578b41d1.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '43d0226962cd5e09af3df17e78e7aa93',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'MODX/Revolution/modSystemSetting/7b9fbe9ebd1f0d8c4e5694ba4a9bb038.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b849a8fa201d17ead90a4a9996c1402d',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'MODX/Revolution/modSystemSetting/dc61104a687f4cb7637de934d3f57071.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e48aaf0aa9b65d81506d5de17369c75e',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'MODX/Revolution/modSystemSetting/6e63876327fec1ed0680ef1caad0e7f2.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '96e8f8350fd62c39244f4769b1e2c7e0',
      'native_key' => 'friendly_urls',
      'filename' => 'MODX/Revolution/modSystemSetting/e47e1ae694fd6c69e7680af514543ff2.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5ddd1a970845b85f3bd5c38a169ae310',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'MODX/Revolution/modSystemSetting/3b02191280719be03cfa523d081a355e.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd88fa5957d41dcebbfeb917185fb6971',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'MODX/Revolution/modSystemSetting/056e80fa02d4dc50b7e149b696dfbe66.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '95550c6fc07c0a633da8f0df55143ec5',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'MODX/Revolution/modSystemSetting/469c8e9a2b402557d407b490187876e3.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '146bb951ee6a87cf90f2de9377250c18',
      'native_key' => 'hidemenu_default',
      'filename' => 'MODX/Revolution/modSystemSetting/c7742b376fea9bb89cd4b58e5caf22bd.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '080481f45cf65929fcf3ad15701571a4',
      'native_key' => 'inline_help',
      'filename' => 'MODX/Revolution/modSystemSetting/b0ea83d5864ed1d8a3928e1586395dfd.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7ee91eae222bd85ec685ebdc30b07925',
      'native_key' => 'locale',
      'filename' => 'MODX/Revolution/modSystemSetting/caf1f0168911d70ddfae1b50492b57b0.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6bf8514ebf9463415d93b633228a8dbe',
      'native_key' => 'log_level',
      'filename' => 'MODX/Revolution/modSystemSetting/e5e994dadd95272c196a70b1eb44f064.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7cb708702b80d4dbdf67f335a362c6bb',
      'native_key' => 'log_target',
      'filename' => 'MODX/Revolution/modSystemSetting/a096c017317c286e9b4ae864dbdfbaea.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a0f5957fe7c2eac078d4487352ec14f0',
      'native_key' => 'log_deprecated',
      'filename' => 'MODX/Revolution/modSystemSetting/50634ac9293796621dee11a1da3082ff.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a3209dd760781e7ad69d36e87b54cd8e',
      'native_key' => 'link_tag_scheme',
      'filename' => 'MODX/Revolution/modSystemSetting/380a29ab219c797b301f369aee85d82a.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '48d82fa24bf038a32c4eb242d31c6efc',
      'native_key' => 'lock_ttl',
      'filename' => 'MODX/Revolution/modSystemSetting/709f9001516e0610c2a37554262d55a3.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '855249e4459fc35d55aa11d883bd2711',
      'native_key' => 'mail_charset',
      'filename' => 'MODX/Revolution/modSystemSetting/2ded9772c7005a2e8c71984ac91a8150.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fd6cb28ce121d39dc8dda8b7a5c19b20',
      'native_key' => 'mail_encoding',
      'filename' => 'MODX/Revolution/modSystemSetting/4f4cb35cbad44378e99ae3b03c82e7fc.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5e5297773959c7fce0b44decde10f24c',
      'native_key' => 'mail_use_smtp',
      'filename' => 'MODX/Revolution/modSystemSetting/5f738343b7945538880e9ce9adaa71d2.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e6b7d9896f5603dabc44b3c47395060a',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'MODX/Revolution/modSystemSetting/3aa45778ede64bdf73004558685b9d67.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1ac233c4cf4040dede28f80a331ef6e7',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'MODX/Revolution/modSystemSetting/cabc34d362ee90ecd10c744a8eb7c5f3.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f4d1027fb586f116fb9d1875302d5ec6',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'MODX/Revolution/modSystemSetting/cfe9cb9ee73c46d127a3c4237c33fc20.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4adb431277fc820cfd28c0f10676b2fb',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'MODX/Revolution/modSystemSetting/57bda076781e7a1709b73a073e3b938f.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dadeb1352055ee513b31f6f6b42a0dc0',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'MODX/Revolution/modSystemSetting/0c63764215f2322e47c20d0a72d420d0.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '71572da8a2229b47cd6be12d4d2ee78a',
      'native_key' => 'mail_smtp_port',
      'filename' => 'MODX/Revolution/modSystemSetting/7179b1e7ff965a51f7e4a96686d27835.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fbadf761b0a3a0137f5247d3add50a72',
      'native_key' => 'mail_smtp_secure',
      'filename' => 'MODX/Revolution/modSystemSetting/167b49323e215b29a0b93188ce159398.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a7ad556fd71788d977bca7bfa8f06779',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'MODX/Revolution/modSystemSetting/e2e25ce0e0983bbeee6aed3d3bc8b1e9.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4d1e0e1a60148483b1b8b53bf5b6a68c',
      'native_key' => 'mail_smtp_autotls',
      'filename' => 'MODX/Revolution/modSystemSetting/97291d5f9796001fdd275841788be5d2.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'aa83c69fbaae81e893e05b9752a424d8',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'MODX/Revolution/modSystemSetting/72eb30618e9e4b200609de4175e9d434.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c659a156ff7fb54f3473c067fbf3b2f7',
      'native_key' => 'mail_smtp_user',
      'filename' => 'MODX/Revolution/modSystemSetting/15e3410bc420d34169471c6a8d25489c.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '01e2f16f65143c5354c52acd469533cb',
      'native_key' => 'manager_date_format',
      'filename' => 'MODX/Revolution/modSystemSetting/774beb833136557259db399f9d095197.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd95abfd633e8da81516c483cf4dd0b6b',
      'native_key' => 'manager_favicon_url',
      'filename' => 'MODX/Revolution/modSystemSetting/99aac2bec57bbc488505458d2fa1b518.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '63d3129ce0da10a30683ecbcca840de4',
      'native_key' => 'manager_time_format',
      'filename' => 'MODX/Revolution/modSystemSetting/cacba8a10652b0b581958ea584c1bedf.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4e514a1075f3cadce3817961930c43de',
      'native_key' => 'manager_direction',
      'filename' => 'MODX/Revolution/modSystemSetting/7240b6f153128328e471ab46e8526fe2.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4925befea1408d816b4a81f34bc1b542',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'MODX/Revolution/modSystemSetting/ba9618edbeb0d9c7212db29575876e1a.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'aa6e6e4e97ca58820ca4d58499b7034a',
      'native_key' => 'manager_tooltip_enable',
      'filename' => 'MODX/Revolution/modSystemSetting/a5a1ffd28a05b247bba34363f34f1b1a.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '41a09854e5aee1d0b08d1e06ae887a63',
      'native_key' => 'manager_tooltip_delay',
      'filename' => 'MODX/Revolution/modSystemSetting/b24cc0ea36573b1a179d5994af80d1e5.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b775df9080e316c887baa0612c82f287',
      'native_key' => 'login_background_image',
      'filename' => 'MODX/Revolution/modSystemSetting/b4f36d4422ce1e0df2a963d72ed4e784.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2771d3351e92b99d6776187ced948081',
      'native_key' => 'login_logo',
      'filename' => 'MODX/Revolution/modSystemSetting/395451faa56aa3a4ab93862faa4b661b.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ff17fa2ec242a8e86df24da31075d864',
      'native_key' => 'login_help_button',
      'filename' => 'MODX/Revolution/modSystemSetting/b12f3d3ec7768dcf30098515a36d17f7.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3dc6b0bf8e3822e559ee536fe0c7dd41',
      'native_key' => 'manager_theme',
      'filename' => 'MODX/Revolution/modSystemSetting/38d41e58cc7acfe758913de3ecf23198.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c36ff2f8dc7dd7d83cd7f38338c7466d',
      'native_key' => 'manager_logo',
      'filename' => 'MODX/Revolution/modSystemSetting/ca8365e260319c8c62c93fb68af95a73.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b954e3a71889b4f93b42d4c19370b1c9',
      'native_key' => 'manager_week_start',
      'filename' => 'MODX/Revolution/modSystemSetting/f8918cc5a72f68f803cb7e5340be6f57.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f048ff1e0576c8eaa768ee71fee650a6',
      'native_key' => 'enable_template_picker_in_tree',
      'filename' => 'MODX/Revolution/modSystemSetting/859e5dda30d0e90d6bbc61ccbacfb66c.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3ea5c0f089b0eec15f3bff163420854e',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'MODX/Revolution/modSystemSetting/cd18e3180d7624ff06d49f26b0fff535.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5dd0178eee4936277cd0a531859ffb95',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'MODX/Revolution/modSystemSetting/dd648e65c860804d86f3bf97f32083a5.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6466523d608cfc728f9629945a6663b6',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/212a919efee1af765575b6f0bd5fc29f.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd05c36dcf3c9a2fac418018f892ff59c',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'MODX/Revolution/modSystemSetting/f4e894249ab5178862d7c8b335006ad2.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0e2b96c4383fe02288f340f62abe8083',
      'native_key' => 'modx_charset',
      'filename' => 'MODX/Revolution/modSystemSetting/512ef12c80f75f06bb1c38bddcac5ef8.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e9b18edcae14c0b6b1e81e5a94bfc3d3',
      'native_key' => 'principal_targets',
      'filename' => 'MODX/Revolution/modSystemSetting/4da2324a6397cf0911e0d135d1ab86bb.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ffdca10fa96514b517dff4ea0e712ad5',
      'native_key' => 'proxy_auth_type',
      'filename' => 'MODX/Revolution/modSystemSetting/af0bebef449b9c98a6633c6982fe1178.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5d938b0298d179f957c5b6e476d48699',
      'native_key' => 'proxy_host',
      'filename' => 'MODX/Revolution/modSystemSetting/dde87aa7263f88453c80dafbf2637d91.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6c913564a4ad123499fcf3b592d06f9a',
      'native_key' => 'proxy_password',
      'filename' => 'MODX/Revolution/modSystemSetting/d244c3349a170b33464cf165ba61e5ad.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bb171e40c7ab5b05426ecc9b7ea5bcfc',
      'native_key' => 'proxy_port',
      'filename' => 'MODX/Revolution/modSystemSetting/247a431678d5b14e8ac6ceb6334cd44f.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '39775f37c8d481a71558930470f69c10',
      'native_key' => 'proxy_username',
      'filename' => 'MODX/Revolution/modSystemSetting/15c42683e0a0aec9b7777d67060db89f.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1043aec8de995c9da3d76b0d0aee276d',
      'native_key' => 'password_generated_length',
      'filename' => 'MODX/Revolution/modSystemSetting/2dffae67afa6e4d7147285062e9269b4.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '396fb851698b29e847f223f3cc68b306',
      'native_key' => 'password_min_length',
      'filename' => 'MODX/Revolution/modSystemSetting/94525e459bf3fda5204d25cf7479add5.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2b895f0282d2c1ee1f7fd41e27d2de69',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'MODX/Revolution/modSystemSetting/23f3e07c86c354646b3e212b36abc85a.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7495531dfbc9ec127f5ba99127641214',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'MODX/Revolution/modSystemSetting/1b35732acc0793d73ff41e797dfee77b.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '66a7a0fc56fbd6d7e1579b3538c0248f',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'MODX/Revolution/modSystemSetting/aa81df65b58776a6b57ccf32058a77d9.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2864e7acee20a9b83cc3fe58257c6c21',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'MODX/Revolution/modSystemSetting/d6aa2ed669850179ed9fa0095c0f470b.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b46e5c2c1b34f441b793d4bd456f9b2a',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/6da6f4176312725a76ed46661e3621db.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '02a3c74d99e27d087b5d169f2f5b9ac0',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'MODX/Revolution/modSystemSetting/e16efb9156550a67be73e4aba7394bbb.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'da4361648d53fdc5f7332285859423a3',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'MODX/Revolution/modSystemSetting/9c220dd24ad6ad61c3ecc21d913f3956.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e5f5a2c21afc20e2873da8b1836b7460',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'MODX/Revolution/modSystemSetting/87847cfdff18d2c15904e8844af11a90.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'feace4ac2a850e992266df344b18931c',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'MODX/Revolution/modSystemSetting/3f4d3c7ead4842880458ddd45c0edf83.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dc563acd5a4ad754b345688299bd74d2',
      'native_key' => 'phpthumb_far',
      'filename' => 'MODX/Revolution/modSystemSetting/aef8182ab4ef3397bdcdb60a84180936.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '38f0b7a9aefd76134e20772d3dd65c58',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'MODX/Revolution/modSystemSetting/8a76f50a17af840c7d55d4590f2bf01d.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1f8da7b92040668aae69b39c1f02cf8a',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/2379bf510c053776d813d31ce8b2d4f0.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fe78385bcc927b1c4f6b09e52058b83c',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'MODX/Revolution/modSystemSetting/19a635d92e92e7340f02a56a8a3eff20.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7b573914922cd0d70a7d8c8c5f4cb9f8',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'MODX/Revolution/modSystemSetting/d942ac166fc09f8645f2f6f0484f62d5.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e660d78bafd76e8b52649e469de2b394',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'MODX/Revolution/modSystemSetting/b4bfd924f524f4aefce9bfee3c3f90a8.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f50a0d625338d31b50fdcc417b86884f',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/9b7ba042b6013e0e1cf3d1bce1558657.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '277c66c005af2990348b7f07d6485a15',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'MODX/Revolution/modSystemSetting/d128f1405bcf1b12289d4016a82a9246.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c5f76b8d5733113c1acf2ac817ee47e7',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'MODX/Revolution/modSystemSetting/c5c39e7e89ae28057d701154c6660519.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dd1f8d55ddf99afb712ac914a55402d6',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'MODX/Revolution/modSystemSetting/c6ee17e9cfb582aecaaed4ad3c994aa7.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8d26f968ed4ab27ee8eb04f37f39a01f',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'MODX/Revolution/modSystemSetting/0b80d5d91a81c92e06dc8e0766e93b4a.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '14c30daac5a119a99786a0dd6d52936c',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'MODX/Revolution/modSystemSetting/15a907898c6937027d2a39823a321554.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '86f11d9a80d36ea619427a76feeb87dc',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'MODX/Revolution/modSystemSetting/2cf0cd2cd8feb13d1d7d984585f58483.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f55f53543b3d7b8253cb2bffc8bfa86d',
      'native_key' => 'publish_default',
      'filename' => 'MODX/Revolution/modSystemSetting/311e1207b19267d1f8c35a7743e682c3.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '50e6adbf067790cb22ab37e654f0bd71',
      'native_key' => 'quick_search_in_content',
      'filename' => 'MODX/Revolution/modSystemSetting/f619a8735eefba1cf45547046d55f6ba.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4886a9da32b5caf524e5ba9844bcf317',
      'native_key' => 'quick_search_result_max',
      'filename' => 'MODX/Revolution/modSystemSetting/1a04328efb895bb3a6c905d04ed1908a.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dedc79bcbc3e9c7f38d98624439797e0',
      'native_key' => 'request_controller',
      'filename' => 'MODX/Revolution/modSystemSetting/44f1fc3cd857124967381c6206c54d54.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c44733da463f75fb93271fd8b066d72f',
      'native_key' => 'request_method_strict',
      'filename' => 'MODX/Revolution/modSystemSetting/5a5aa20f2334e603092ec5998bc2ed2b.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '47f139303ff560701b697798a4ed80e8',
      'native_key' => 'request_param_alias',
      'filename' => 'MODX/Revolution/modSystemSetting/35899c7d2410f4eaf61ea230557fcd34.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '75564c52d3286b834a5bcbaecfe1b4cc',
      'native_key' => 'request_param_id',
      'filename' => 'MODX/Revolution/modSystemSetting/d2c5f39f40a0b2bb7c1d30eb35d585d0.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '85c0e325f988cf38846ce01b50dc8b60',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'MODX/Revolution/modSystemSetting/abf4fac9042e0218f1493a6a24b6e49a.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '62d51fa8edd90076625b7b7f56707a64',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'MODX/Revolution/modSystemSetting/a726e01213939ac612761a85bb8c739f.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c2c0b8d7513604453054a159d2376c9b',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'MODX/Revolution/modSystemSetting/e123c878702ff6102a6a3cdce24c6477.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6ed03b14afc89e8e1d9b12ace04ae398',
      'native_key' => 'richtext_default',
      'filename' => 'MODX/Revolution/modSystemSetting/df797697a26e757e25e936b0d1b9d9a4.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a87c77e2519c9c1b723e9691f371be35',
      'native_key' => 'search_default',
      'filename' => 'MODX/Revolution/modSystemSetting/3a0291f6331a8da6f79d6f82e641bdb8.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5149c567852ae8551fb5295d162db87b',
      'native_key' => 'server_offset_time',
      'filename' => 'MODX/Revolution/modSystemSetting/303bbf78443c81c8356733bb9a9b2377.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c8fa1ab024c3c59044cadd6fd0427679',
      'native_key' => 'session_cookie_domain',
      'filename' => 'MODX/Revolution/modSystemSetting/451e7f5e63f7ff3888e27879077f14a1.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '353aa7b12382273c562ca73d20e4d4a1',
      'native_key' => 'default_username',
      'filename' => 'MODX/Revolution/modSystemSetting/a6982eb64dc6125dd61415851208404a.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c51af364a7deca0072a90df21fd9edb5',
      'native_key' => 'anonymous_sessions',
      'filename' => 'MODX/Revolution/modSystemSetting/fe45d068000c4084513d775832c3d337.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2e059abb0501c3e41ead2f6992bdb4c5',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/ff19746a1feb46f85ae8b48f38775ae5.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f5adfc6dfc8630615baf2a28e6eebb8b',
      'native_key' => 'session_cookie_path',
      'filename' => 'MODX/Revolution/modSystemSetting/b659c51eec96b65ad3ff56600e741a5e.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5a9c30863db75039ef02739e50a06141',
      'native_key' => 'session_cookie_secure',
      'filename' => 'MODX/Revolution/modSystemSetting/cbe10c08209cb2cd0e47350cafa07faf.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'af9f65e05e29f747b502e01e10e2d089',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'MODX/Revolution/modSystemSetting/bf15c7a940bc1a626ebf6fac679bd40a.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '79b4d50535b1bc5b71761335b3ce1ef5',
      'native_key' => 'session_cookie_samesite',
      'filename' => 'MODX/Revolution/modSystemSetting/5293c0869408e38651166c0e76c200e2.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd4f7ecc74bd65333dc0a2642eb8fe5c5',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/4ba824639a445f49fb075455cf5c86c2.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7f153789247034a532682760ec7b73c7',
      'native_key' => 'session_handler_class',
      'filename' => 'MODX/Revolution/modSystemSetting/c074bf531aaef684ce35343daff8aa3e.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4f16af9e9c9fa92b11130ebc8babc688',
      'native_key' => 'session_name',
      'filename' => 'MODX/Revolution/modSystemSetting/806da340d5115a56971e7a82054ef4ed.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6c77cc89d9d69e05b98fc34fa5c9ddf6',
      'native_key' => 'set_header',
      'filename' => 'MODX/Revolution/modSystemSetting/9ed078a6f0d75a59ab2615e42e06b0aa.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '45cba2d625da995491fcd80115fb6721',
      'native_key' => 'send_poweredby_header',
      'filename' => 'MODX/Revolution/modSystemSetting/3b0f7912dda56f9c56e5bc1cd67bb4d8.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ba884fef0afad5d16daff7a99373ee23',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'MODX/Revolution/modSystemSetting/87911a10ba99c6007243c9d3ae781cdf.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c60a15fb57b7e6dd3882428280d8fe18',
      'native_key' => 'site_name',
      'filename' => 'MODX/Revolution/modSystemSetting/1cf8bf5446f1e2ecc1ffcd412ae68f3e.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '11758d922e7811d261f46e857a42c2cb',
      'native_key' => 'site_start',
      'filename' => 'MODX/Revolution/modSystemSetting/256a72f0b073a6d99071059c5fcd2c90.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7b78b1cbbd6681683ac298eb7dff4182',
      'native_key' => 'site_status',
      'filename' => 'MODX/Revolution/modSystemSetting/2b5883bad27bfd40b5eb4d70db04c834.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b4baf5a36e649742c8d8cc1dfd82d93b',
      'native_key' => 'site_unavailable_message',
      'filename' => 'MODX/Revolution/modSystemSetting/66431e7471162080dcdaa04dbfb6d8c5.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '211e12be005871c4ffb2ce4105eda484',
      'native_key' => 'site_unavailable_page',
      'filename' => 'MODX/Revolution/modSystemSetting/31373b4a2975b8e7c612fa7115692055.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ff2c62882568244b57b885dbe1eaa19c',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'MODX/Revolution/modSystemSetting/23c0bc83aff18269490b9d192062ee73.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ce3c8772a3e6897f903f570ccd6de148',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'MODX/Revolution/modSystemSetting/b8bc087633d916ecaa85842538e2bc0f.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3db1f12063fada3d978ede13e9530854',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'MODX/Revolution/modSystemSetting/b6e306ca28f13a612cdb3927bfd385f0.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '89963c40bad97058488f0ce94f0334c0',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'MODX/Revolution/modSystemSetting/b4a0c8eaa08e738fe5a5bca3cd1a5d8d.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '04aa9637c013e45b2407ed993dfdf0c9',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'MODX/Revolution/modSystemSetting/a084b79fa513a523089564b598a1068f.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '026284d980e43a3f3174843c6fc8d270',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'MODX/Revolution/modSystemSetting/ef3b4e6904916d8c3c6e3f1e5dec27a5.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f3a5f5469aff75d6b0f88277c228ebcc',
      'native_key' => 'static_elements_default_category',
      'filename' => 'MODX/Revolution/modSystemSetting/5f2fa3eaa66adc7dabf5ee3fead1fdac.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '21e23ef665d94641078fe5ce03ea81b0',
      'native_key' => 'static_elements_basepath',
      'filename' => 'MODX/Revolution/modSystemSetting/5c87f19b7f13d914c3de0ab34fa20612.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '005d3bc37b2de571389b63de222ab5c1',
      'native_key' => 'resource_static_allow_absolute',
      'filename' => 'MODX/Revolution/modSystemSetting/7b3f98949df48c08253328021e8af148.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c91384c49001bda8d799e5806eff87d1',
      'native_key' => 'resource_static_path',
      'filename' => 'MODX/Revolution/modSystemSetting/ae16a1b1c4a481c8fa80a14c81033172.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd2c334edcf35b6a0c2d17ea4a170f4b0',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'MODX/Revolution/modSystemSetting/c9831710abcd03c00c606ea6a35bd255.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8595de55fbd8be43c1375446ae578441',
      'native_key' => 'syncsite_default',
      'filename' => 'MODX/Revolution/modSystemSetting/025ce9460cf93398459f78ad9ff5bbc7.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '86c3091e09840484e8caf07a79b4049c',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'MODX/Revolution/modSystemSetting/087cf324f40370d9522989e38a9ad3db.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9ae93ff0e0e5bd167830dcc53c6eccf8',
      'native_key' => 'tree_default_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/65e5d0eabaac7baaac6a12fc9bd7e773.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1c1c32661bac16d22fa3009e2f447fd8',
      'native_key' => 'tree_root_id',
      'filename' => 'MODX/Revolution/modSystemSetting/91e3271eb8eba80c399f68de9a5c44d3.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '11d8dfc9150017e38175d144fd727386',
      'native_key' => 'tvs_below_content',
      'filename' => 'MODX/Revolution/modSystemSetting/97b02382795d3a75d40aad984a4d362c.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd4302822d6f254c013633ccb2e3eef74',
      'native_key' => 'unauthorized_page',
      'filename' => 'MODX/Revolution/modSystemSetting/b565db6bca3d0112f6d3a9e0b85858b3.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1edcff6de0bb3810042e048918d0329f',
      'native_key' => 'upload_files',
      'filename' => 'MODX/Revolution/modSystemSetting/d13dd66e30708428d5704cf76048053f.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0085962e52f0a329ca8cc51a75a4472a',
      'native_key' => 'upload_file_exists',
      'filename' => 'MODX/Revolution/modSystemSetting/3836d832142087a65056aa4bb9c2f1ab.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e133616192ee668940a7d153620fa851',
      'native_key' => 'upload_images',
      'filename' => 'MODX/Revolution/modSystemSetting/0a3bee2890987e7166a378804f96b240.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0770fc008446214b24fccb48008e1c70',
      'native_key' => 'upload_maxsize',
      'filename' => 'MODX/Revolution/modSystemSetting/4acc1fbe1b9623225ccd3fe9029eaf09.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8874237f799cb20cf02c8fd94a35c71a',
      'native_key' => 'upload_media',
      'filename' => 'MODX/Revolution/modSystemSetting/777b0add581027c115ac6a81cfa3b8f4.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd52675a159e08e6670c730f27dc458b5',
      'native_key' => 'upload_translit',
      'filename' => 'MODX/Revolution/modSystemSetting/3dcbaf91109f55d6db025bca3e3defbb.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f3e58e21d4d8f17a3fccc676f5cca7ea',
      'native_key' => 'use_alias_path',
      'filename' => 'MODX/Revolution/modSystemSetting/18dbff20930f9ad90d1c7fc632429b87.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b6833918a7abb88e08f1ac52fca4009a',
      'native_key' => 'use_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/ad03ff2524d50614b93e3cfa733536ee.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c61a54eb6a3e544db7fb26ac48a7bced',
      'native_key' => 'use_multibyte',
      'filename' => 'MODX/Revolution/modSystemSetting/08a06c434eefa1eceb7380953d719a58.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4c1e2792cd09df5f267848bedd2aff5a',
      'native_key' => 'use_weblink_target',
      'filename' => 'MODX/Revolution/modSystemSetting/a91ec54d0728c697e721b5e68f5911c2.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '48037857330be5da869b79eb842b75f2',
      'native_key' => 'welcome_screen',
      'filename' => 'MODX/Revolution/modSystemSetting/f9db11b14460dd96a5a8b33a7ba9be7c.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '75e1e1b2bbc04e6d94df71764fdb5dcc',
      'native_key' => 'welcome_screen_url',
      'filename' => 'MODX/Revolution/modSystemSetting/8fdf51e0e5c06b87711b5ee097ad0c4e.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ddffcd0d7ee2a388e2a773fc87af3fe7',
      'native_key' => 'welcome_action',
      'filename' => 'MODX/Revolution/modSystemSetting/56ee09223e2cd21c11b1c1a573c7fb7b.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7efbb29b58f9fbcc23a7bc967220b11a',
      'native_key' => 'welcome_namespace',
      'filename' => 'MODX/Revolution/modSystemSetting/4f56ffbd79eb14dde2986b6c531c2c72.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd52f4680a0ca2ba5a2ad797721168930',
      'native_key' => 'which_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/257929113d5e197512991272c0c4f44c.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '55ce2e64fc0cc87ee24195c75df12570',
      'native_key' => 'which_element_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/3a4dcefb36e0b68c482447b70af735e3.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd73de7eae05fe1bcb4a715b61db7bffa',
      'native_key' => 'xhtml_urls',
      'filename' => 'MODX/Revolution/modSystemSetting/5a67f0250d03c2840e05dcf1db729cf5.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4dba54032058c343919f8deabd9bdcf0',
      'native_key' => 'enable_gravatar',
      'filename' => 'MODX/Revolution/modSystemSetting/713ad8b5bd758259b0de43546209f796.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '473936e68a58de800488547dbe38f4c8',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'MODX/Revolution/modSystemSetting/1a7ee88ec76cb3a9874908fa5b12ff0e.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd5e44ccb3fb416d48a250aa0dcd4b9bc',
      'native_key' => 'mgr_source_icon',
      'filename' => 'MODX/Revolution/modSystemSetting/e306c6ec76b0714fb1bb37358d358c4d.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '746d9e769a8d5be1f1d1eead016e7176',
      'native_key' => 'main_nav_parent',
      'filename' => 'MODX/Revolution/modSystemSetting/8c6d63a7d2affbfae8e29c8d14135df1.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd4d28820bb5cc46aaeb754d7bb8d752f',
      'native_key' => 'user_nav_parent',
      'filename' => 'MODX/Revolution/modSystemSetting/32e6853e74520035aa11d195a4e341cf.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '606cadab26a6c8b36cc0c276ddd51a6d',
      'native_key' => 'auto_isfolder',
      'filename' => 'MODX/Revolution/modSystemSetting/1490f0b0d117989721ace55b25e09b74.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '179433306410847b31048a7870e1607a',
      'native_key' => 'manager_use_fullname',
      'filename' => 'MODX/Revolution/modSystemSetting/daf56de0b0dc833cac86c205b827580d.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '52ec4aea22b78105799a30bcdd4bbc5f',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'MODX/Revolution/modSystemSetting/e7b357369919ea796e31c51dbc1fe06d.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '360faf9f607b74eb9bc09db6814be573',
      'native_key' => 'preserve_menuindex',
      'filename' => 'MODX/Revolution/modSystemSetting/88765f4171f8f8c11586484d0e878a31.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ab9514293d807463733d5685ab6b2436',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'MODX/Revolution/modSystemSetting/08cf2be9b750c60c78862c97795d919e.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '42fd1983a5692b5188d23767f28a3188',
      'native_key' => 'error_log_filename',
      'filename' => 'MODX/Revolution/modSystemSetting/62691d17e1c9ec79a8467a48a9fab8d9.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '37dca7d499070901313700315b94c25e',
      'native_key' => 'error_log_filepath',
      'filename' => 'MODX/Revolution/modSystemSetting/e0c23fbeccb72daf019f4afb42ba0897.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd731a674ff3a6168a3eafa90df2442fd',
      'native_key' => 'passwordless_activated',
      'filename' => 'MODX/Revolution/modSystemSetting/e789ce93b0db88241d203c3af877f23e.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd64d799dc685a5e94c7acfe09b0553e7',
      'native_key' => 'passwordless_expiration',
      'filename' => 'MODX/Revolution/modSystemSetting/be7ae0a79543f7169ace999ec0d2d973.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a57c0889c762bd624187682fef84cd56',
      'native_key' => 'static_elements_html_extension',
      'filename' => 'MODX/Revolution/modSystemSetting/e5cf79ebe68776e00c1a20402aae2f4b.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContextSetting',
      'guid' => 'd449de1736f9bceefa687d39672f3359',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'MODX/Revolution/modContextSetting/c473176a7ed1028a8910730022b141f6.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContextSetting',
      'guid' => '1e4cb4939aac25ccf360dde016b8bf77',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'MODX/Revolution/modContextSetting/534887ead1024d181b8005354da0b34b.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroup',
      'guid' => 'e6b6f19053b86258423100c62b6087c8',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modUserGroup/83387b480fa7a1fbb7ec2c82b96f20e7.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboard',
      'guid' => '9dcf80c85167e55bc284a9b2a39cfe78',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modDashboard/8cd0fb1271db91d14ded078864515520.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\Sources\\modMediaSource',
      'guid' => '1ccbb3310553785c448aec5750e88afe',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/Sources/modMediaSource/78521694dcf27c6b2de8386b390eb37c.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'ab0d626f43b2301ea34fbcb316100d4e',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/5499d7b38dda377ce0ab1f143ffeddff.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '1a40dd7d68d56606c1b142c6f0852e71',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/9c4c23d934fae9d01d7f8539247189ca.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'c7f037d3cd13ae6025583438c759d1b3',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/c059714b0a4fec1006eed83900976cda.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '3650c49d7345adc8ec05bdfe4978fa69',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/da118a332093c8e7d075dfc40c2177e9.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'cb9e578d0bb87a9e66e3f087e789dfc6',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/626dcd2953fbe4961996ec9ff422006c.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'dc50cfff840ad869f09d875a6d4be61e',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/014aa3be2ec2c3ac16247f9dc6e478c7.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '5f28fcdf62f92f4b10020b295374f15e',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/5f2047b51c1aa591c77b4ce8fec0797e.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroupRole',
      'guid' => 'ccf6db0432a4fab497ad016213a463dc',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modUserGroupRole/39ef0c6459f0f9983bbba4805a2a6024.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroupRole',
      'guid' => '41fdc0f7d7849682c92f68225add08d8',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modUserGroupRole/e272df77a8150ae7dcbe7b3c6d8b4ec2.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '2094439f44356a6719964c6383083c8d',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/9305794a0627e21f4244b8ef66adf490.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '4312312226e0796303a63804959f0908',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/96e45b568ed1ec2403cbe16cc825c7f1.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '0de96e25c3361f8c4c6f5ebad2cee94c',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/d0ad94ca5b9b64398a92c8659d5f8486.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => 'cae6999f50d6e8c093e2e2640218facf',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/b413b7bf4eddde1d64177c7c2cd7ab17.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => 'e864f97868da5e6d46e66b072993b06a',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/ae3749bdf53de37151cf8e4e81f24d1b.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '2832c8aed09fed4a0906db695084f279',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/8e956c11d05ea1d811815ae2bbe03702.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '9f89ac6728ad44e1910d3b5bb62ed146',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/691576c1b74bad72f0adfac57a711aea.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '3eef4764d5295ae56d956e693aaf83cf',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/4081c68f828059e1a23eb54d24aa58b2.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '264680f4282cc41f942487452aa06c73',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/c85c56bc6f95536bbd82dd518d25dd1a.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '9d8a0b192dd8ed09abcbfd74da6e80e2',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/14b9f26631ba5b1b4914b843b2dba293.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '39ddfa3101e10f2c16d12262055f8e9d',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/3245e49fd8dc24dd78140e1faf926bbb.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'ea43cf7e29aa000d759c98943ff14ad9',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/a1abf39772e175a5979e38669f500328.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'e4dcd407dfffe7e32043b9575d2d9fac',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/60a82718799aa5f180ef1d609d7eb7b9.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '56445e06218e66e8b36f10ed130a92e0',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/05ff6633f77391fa20f101360024f9c1.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '7e213d78b849c0d94fbb73c71516c2ad',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modAccessPolicy/6a60f7a0d58df2708bf17f9efccde656.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '669ec29bfce5ec97c9142ee89404c91c',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modAccessPolicy/3f281e6baa9197d994eecf825d930be7.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '360d0f93c8aa96095cd4a856ba0917aa',
      'native_key' => 3,
      'filename' => 'MODX/Revolution/modAccessPolicy/1160bbea1af66d5babb1954efcd32011.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '3c540cef23d8c7a5c83af7284b502108',
      'native_key' => 4,
      'filename' => 'MODX/Revolution/modAccessPolicy/890a9db706db53fa9d7d250740ce730c.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'd1cc3ba7521ec23fccb07dffb2aa93e4',
      'native_key' => 5,
      'filename' => 'MODX/Revolution/modAccessPolicy/c5c8cb3c66ce278b75f0c5563ca1fb79.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '2428327b11faecf78e0df789c7bfe7e7',
      'native_key' => 6,
      'filename' => 'MODX/Revolution/modAccessPolicy/e9dd894b55e1eb0228c153bdc46e9325.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'd576c28ee1ee340dc887ae75515b725b',
      'native_key' => 7,
      'filename' => 'MODX/Revolution/modAccessPolicy/16269070236eab9a587441f7be8ce308.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'f259660c122b4379273e008de20b2031',
      'native_key' => 8,
      'filename' => 'MODX/Revolution/modAccessPolicy/26ed981ebe684076e5878ef93a7dcc04.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'a6dc86ce168ac35a9b4daff93b92c4d8',
      'native_key' => 9,
      'filename' => 'MODX/Revolution/modAccessPolicy/b63fff74d3a1c4580b6c264ed19561c2.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '5f5d9420f122a004dee0b7ff7d749f0d',
      'native_key' => 10,
      'filename' => 'MODX/Revolution/modAccessPolicy/1dc715d0ef12f0b441e3948f0a41cd3e.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '0aa1466d141e00d5ee34eb5b92506224',
      'native_key' => 11,
      'filename' => 'MODX/Revolution/modAccessPolicy/3fe593051b7bae3ccef06a65932cf4c6.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '926093f8cf2ee2a983b433ab0dbab504',
      'native_key' => 12,
      'filename' => 'MODX/Revolution/modAccessPolicy/250ae244c73700205cab91432a02421b.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContext',
      'guid' => '05847901c5b9d0501f683e646e88f601',
      'native_key' => 'web',
      'filename' => 'MODX/Revolution/modContext/42e9f5f863e0c82f022dfc0d216f3f7a.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContext',
      'guid' => 'ef7e055839b80769690ddbcb23c69708',
      'native_key' => 'mgr',
      'filename' => 'MODX/Revolution/modContext/9e783179b7b78234093f6f977002ebde.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'd321a7e6e8b4c3c5b18aac1ecb5d8eb7',
      'native_key' => 'd321a7e6e8b4c3c5b18aac1ecb5d8eb7',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/2f2a7757b39302423ea17b498a4ea0c4.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'f5f1f05f1dd2bd473547df9fe705c6fb',
      'native_key' => 'f5f1f05f1dd2bd473547df9fe705c6fb',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/fef1a9b66c11dabc1f01d4295df2f6ce.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '871f4fbfe3d84f90b64e51b5f934aa09',
      'native_key' => '871f4fbfe3d84f90b64e51b5f934aa09',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/01716a053c700f05de4f0c5f72b61476.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'c2ffec7b978962000380b8c73d0b2c5e',
      'native_key' => 'c2ffec7b978962000380b8c73d0b2c5e',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/6abe857e40430828910df95c40a4cee2.vehicle',
    ),
  ),
);